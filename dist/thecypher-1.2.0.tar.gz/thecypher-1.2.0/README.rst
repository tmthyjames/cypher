Welcome to the cypher

=======================

Easily get music lyrics
